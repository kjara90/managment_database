USE MASTERI;


-- Krijohen logins per administratorin financat dhe nutricionistet
     
    CREATE LOGIN administrator WITH PASSWORD = 'admin123' MUST_CHANGE,
	CHECK_EXPIRATION = ON,
	CHECK_POLICY = ON,
	DEFAULT_DATABASE = MASTERI;

    CREATE LOGIN financat WITH PASSWORD = 'financa123' MUST_CHANGE,
	CHECK_EXPIRATION = ON,
	CHECK_POLICY = ON,
	DEFAULT_DATABASE = MASTERI;

    CREATE LOGIN nutricionisti WITH PASSWORD = 'nutricionist123' MUST_CHANGE,
	CHECK_EXPIRATION = ON,
	CHECK_POLICY = ON,
	DEFAULT_DATABASE = MASTERI;


-- Krijohen users
CREATE USER administrator;
CREATE USER financat;
CREATE USER nutricionisti;

-- Krijohen rolet
CREATE ROLE administrator_role;
CREATE ROLE financat_role;
CREATE ROLE nutricionisti_role;

-- Shtohen anetaret te rolet
ALTER ROLE administrator_role ADD MEMBER administrator;
ALTER ROLE financat_role ADD MEMBER financat;
ALTER ROLE nutricionisti_role ADD MEMBER nutricionisti;

--Jepen privilegjet administratorit
grant select, update, insert, delete on [dbo].[Klienti] to administrator_role
grant select, update, insert, delete on [dbo].[Dieta] to administrator_role
grant select, update, insert, delete on [dbo].[Abonim] to administrator_role
grant select, update, insert, delete on [dbo].[Gjendje_Shendtesore] to administrator_role
grant select, update, insert, delete on [dbo].[Porosi] to administrator_role
grant select, update, insert, delete on [dbo].[Punonjes] to administrator_role
grant select, update, insert, delete on [dbo].[Klienti_Abonim] to administrator_role
grant select, update, insert, delete on [dbo].[Klienti_Gjendje_Shendtesore] to administrator_role
grant select, update, insert, delete on [dbo].[Abonim_Porosi] to administrator_role
grant select, update, insert, delete on [dbo].[Porosi_Punonjes] to administrator_role
grant select, update, insert, delete on [dbo].[Porosi_Dieta] to administrator_role
grant select, update, insert, delete on [dbo].[Dieta_Gjendje_Shendtesore] to administrator_role

-- Departamentit te finances i duhen te drejta per select tek klientet te drejta te plota tek  porosia dhe abonimi te drejta per select tek  dieta te drejta te plota tek punonjesit
grant select, update, insert, delete on [dbo].[Klienti] to financat_role
grant select, update, insert, delete on [dbo].[Klienti_Abonim] to financat_role
grant select, update, insert, delete on [dbo].[Abonim_Porosi] to financat_role
grant select, update, insert, delete on [dbo].[Porosi_Punonjes] to financat_role
grant select on [dbo].[Porosi_Dieta] to financat_role
grant select on [dbo].[Dieta] to financat_role
grant select, update, insert, delete on [dbo].[Porosi] to financat_role
grant select, update, insert, delete on [dbo].[Punonjes] to financat_role

--Nutricionistet kane te drejta te plota tek  dietat, gjendjet shendetesore te kete te drejta per te select porosite, klientet
grant select on [dbo].[Klienti] to nutricionisti_role
grant select, update, insert, delete on [dbo].[Dieta] to nutricionisti_role
grant select, update, insert, delete on [dbo].[Gjendje_Shendtesore] to nutricionisti_role
grant select, update, insert, delete on [dbo].[Dieta_Gjendje_Shendtesore] to nutricionisti_role
grant select, update, insert, delete on [dbo].[Porosi_Dieta] to nutricionisti_role
grant select on [dbo].[Klienti_Gjendje_Shendtesore] to nutricionisti_role
grant select on [dbo].[Porosi] to nutricionisti_role
grant select on [dbo].[Porosi_Punonjes] to nutricionisti_role

--shfaqa e raportit te klienteve se cfare abonimi kane kryer dhe kostoja
CREATE VIEW Shitjet AS
SELECT 
    Klienti.Emer AS Emri_i_Klientit,
    Klienti.Adresa AS Adresa,
    Klienti.Email,
    Porosi.Porosi_id,
    Porosi.Data AS Data_e_Porosise,
    Porosi.Kosto,
    Porosi.Pershkrim
FROM 
    Porosi
JOIN 
    Abonim ON Porosi.Abonim_id = Abonim.Abonim_id
JOIN 
    Klienti ON Abonim.Klienti_id = Klienti.Klient_id;
select * from Shitjet;

--Krijimi i nje raporti per dietat dhe se si kane ndikuar gjendjet shendetesore ne to
CREATE VIEW Dietat AS
SELECT 
    D.Emer_dieta AS Emri_Dieta,
    D.Numri_kalorive AS Kalorite,
    G.Emer_gjendje AS Gjendja_Shendetesore,
    G.Pershkrim AS Pershkrimi_Gjendjes,
    G.Ndikimi_diet AS Impakti_Diete
FROM 
    Dieta D
JOIN 
    Dieta_Gjendje_Shendtesore DG ON D.Dieta_id = DG.Dieta_id
JOIN 
    Gjendje_Shendtesore G ON DG.Gjendje_Shendtesore_id = G.Gjendje_Shendtesore_id;

	select * from Dietat;

-- kalorit mesatare te dietes per nje gjendje shendetesore specifike
CREATE FUNCTION Kalori_Gjendje (@Gjendje_Shendetesore_id INT)
RETURNS DECIMAL(10, 2)
AS
BEGIN
    DECLARE @KaloritMesatare DECIMAL(10, 2);
    SELECT @KaloritMesatare = AVG(D.Numri_kalorive)
    FROM Dieta D
    INNER JOIN Dieta_Gjendje_Shendtesore DG ON D.Dieta_id = DG.Dieta_id
    WHERE DG.Gjendje_Shendtesore_id = @Gjendje_Shendetesore_id;

    RETURN ISNULL(@KaloritMesatare , 0);
END;
SELECT dbo.Kalori_Gjendje(1) AS KaloritMesatare;
--te ardhurat nga abonimet ne nje interval kohe
CREATE FUNCTION TE_Ardhurat_Abonim(@DataFillimit DATE, @DataMbarimit DATE)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @TeArdhuraTotale DECIMAL(18, 2);

    SELECT @TeArdhuraTotale  = SUM(A.Cmimi)
    FROM Abonim A
    WHERE A.Data_fillimit <= @DataMbarimit AND A.Data_mbarimit >= @DataFillimit;

    RETURN ISNULL(@TeArdhuraTotale, 0);
END;
SELECT dbo.TE_Ardhurat_Abonim('2023-01-01', '2023-12-31') AS TeArdhuraTotale;
