USE MASTERI;

--TABELA POROSI

--Krijojme Partition Function
CREATE PARTITION FUNCTION pf_PartitionByYear (DATE)
AS RANGE RIGHT FOR VALUES ('2022-01-01', '2023-01-01', '2024-01-01');

--Krijojme PARTITION SCHEME 
CREATE PARTITION SCHEME ps_PartitionByYear
AS PARTITION pf_PartitionByYear
ALL TO ([PRIMARY]);

--Krijojme Table Porosi
CREATE TABLE Porosi1 (
    Porosi_id INT,
    Data DATE,
    Kosto DECIMAL(10, 2),
    Pershkrim NVARCHAR(255),
    Abonim_id INT,
    CONSTRAINT PK_Porosi PRIMARY KEY CLUSTERED (Porosi_id, Data)
)
ON ps_PartitionByYear(Data);

--Bejme nonclusterd Indexim Te Abonim_id
CREATE NONCLUSTERED INDEX IX_Klienti_Abonim ON Porosi1(Abonim_id)
ON ps_PartitionByYear(data);



-- Tabela ABONIM

--Vendosem qe kufizimet e particionimit te jene sipas Cmimit
--0 - 100, 100 - 200, 200 - 300, ..., 500 - vlera maximale

--Krijojme Partition Function
CREATE PARTITION FUNCTION pf_PartitionByPrice (DECIMAL(10, 2))
AS RANGE RIGHT FOR VALUES (
    100.00, 200.00, 300.00, 400.00, 500.00, 600.00
);

--Krijojme Partition Scheme
CREATE PARTITION SCHEME ps_PartitionByPrice
AS PARTITION pf_PartitionByPrice
ALL TO ([PRIMARY]); 

--Krijojme tabelen Abonim te patricionuar

CREATE TABLE Abonim5 (
    Abonim_id INT ,
    Data_fillimit DATE,
    Data_mbarimit DATE,
    Cmimi DECIMAL(10, 2),
    Klienti_id INT,
    FOREIGN KEY (Klienti_id) REFERENCES Klienti(Klient_id)
) ON ps_PartitionByPrice(Cmimi);

--Bejme nonclusterd Indexim Te Cmimi
CREATE NONCLUSTERED INDEX IX_Klienti_Cmimi ON Abonim5(Klienti_id)
ON ps_PartitionByPrice(Cmimi);




