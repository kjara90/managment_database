CREATE DATABASE MASTERI;

USE MASTERI;

CREATE TABLE Klienti (
		Klient_id INT PRIMARY KEY,
		IBAN VARCHAR(30) UNIQUE,
		Numri_telefonit INT ,
		Emer VARCHAR(100) NOT NULL,
		Adresa VARCHAR(100),
		Email VARCHAR(100) UNIQUE,
	    Gjinia CHAR(1) CHECK (Gjinia IN ('M', 'F'))
	);
	

	CREATE TABLE Abonim (
		Abonim_id INT PRIMARY KEY,
		Data_fillimit DATE,
		Data_mbarimit DATE,
		Cmimi DECIMAL(10, 2),
		Klienti_id INT,
		FOREIGN KEY (Klienti_id) REFERENCES Klienti(Klient_id)
	);



	CREATE TABLE Porosi (
		Porosi_id INT PRIMARY KEY,
		Data DATE,
		Kosto DECIMAL(10, 2),
		Pershkrim TEXT,
		Abonim_id INT,
		FOREIGN KEY (Abonim_id) REFERENCES Abonim(Abonim_id)
	);

	CREATE TABLE Punonjes (
		Punonjes_id INT PRIMARY KEY,
		Emer VARCHAR(30) NOT NULL,
		Gjinia CHAR(1) CHECK (Gjinia IN ('M', 'F')),
		Paga DECIMAL(10, 2),
		Date_lindje DATE,
		Specializimi VARCHAR(50)
	);

	CREATE TABLE Dieta (
		Dieta_id INT PRIMARY KEY,
		Emer_dieta VARCHAR(30) UNIQUE,
		Pershkrim_dieta TEXT,
		Numri_kalorive INT
	);

	CREATE TABLE Gjendje_Shendtesore (
		Gjendje_Shendtesore_id INT PRIMARY KEY,
		Emer_gjendje VARCHAR(100) UNIQUE,
		Pershkrim TEXT,
		Kronike  BIT,
		Ndikimi_diet VARCHAR(100),
		Alergji TEXT,
		Historikui TEXT
	);

	CREATE TABLE Klienti_Abonim (
		Klienti_id INT,
		Abonim_id INT,
		PRIMARY KEY (Klienti_id, Abonim_id),
		FOREIGN KEY (Klienti_id) REFERENCES Klienti(Klient_id),
		FOREIGN KEY (Abonim_id) REFERENCES Abonim(Abonim_id)
	);

	CREATE TABLE Abonim_Porosi (
		Abonim_id INT,
		Porosi_id INT,
		PRIMARY KEY (Abonim_id, Porosi_id),
		FOREIGN KEY (Abonim_id) REFERENCES Abonim(Abonim_id),
		FOREIGN KEY (Porosi_id) REFERENCES Porosi(Porosi_id)
	);

	CREATE TABLE Porosi_Punonjes (
		Porosi_id INT,
		Punonjes_id INT,
		PRIMARY KEY (Porosi_id, Punonjes_id),
		FOREIGN KEY (Porosi_id) REFERENCES Porosi(Porosi_id),
		FOREIGN KEY (Punonjes_id) REFERENCES Punonjes(Punonjes_id)
	);

	CREATE TABLE Porosi_Dieta (
		Porosi_id INT,
		Dieta_id INT,
		PRIMARY KEY (Porosi_id, Dieta_id),
		FOREIGN KEY (Porosi_id) REFERENCES Porosi(Porosi_id),
		FOREIGN KEY (Dieta_id) REFERENCES Dieta(Dieta_id)
	);
	CREATE TABLE Dieta_Gjendje_Shendtesore (
		Dieta_id INT,
		Gjendje_Shendtesore_id INT,
		PRIMARY KEY (Dieta_id, Gjendje_Shendtesore_id),
		FOREIGN KEY (Dieta_id) REFERENCES Dieta(Dieta_id),
		FOREIGN KEY (Gjendje_Shendtesore_id) REFERENCES Gjendje_Shendtesore(Gjendje_Shendtesore_id)
	);

	CREATE TABLE Klienti_Gjendje_Shendtesore (
		Klienti_id INT,
		Gjendje_Shendtesore_id INT,
		PRIMARY KEY (Klienti_id, Gjendje_Shendtesore_id),
		FOREIGN KEY (Klienti_id) REFERENCES Klienti(Klient_id),
		FOREIGN KEY (Gjendje_Shendtesore_id) REFERENCES Gjendje_Shendtesore(Gjendje_Shendtesore_id)
	);