--STORED PROCEDURE

USE MASTERI; 
--  Stored procedure parametrike e cila kethen informacionin e abonimeve p�r nj� klient t� caktuar bazuar n� Klient_id.
  
CREATE PROCEDURE GetClientSubscriptionsByClientId
    @TargetKlientId INT
AS 
BEGIN 
    SELECT  
        K.Klient_id, 
        K.Emer AS 'Emri', 
        K.IBAN, 
        A.Abonim_id, 
        A.Data_fillimit, 
        A.Data_mbarimit, 
        A.Cmimi 
    FROM Klienti AS K 
    LEFT JOIN Abonim AS A ON K.Klient_id = A.Klienti_id
    WHERE K.Klient_id = @TargetKlientId; 
END;
EXEC GetClientSubscriptionsByClientId @TargetKlientId = 10;


CREATE PROCEDURE GetEmployeesBySpecialization 

    @TargetSpecialization VARCHAR(50) 

AS 

BEGIN 

    SELECT  

        Punonjes_id, 

        Emer, 

        Specializimi 

    FROM Punonjes 

    WHERE Specializimi = @TargetSpecialization; 

END; 

EXEC GetEmployeesBySpecialization  

    @TargetSpecialization = 'I specializuar ne kardiologji'; 
	

-- Stored procedure p�r t� marr� informacion p�r diet�n dhe klient�t q� e kan� porositur
CREATE PROCEDURE MerrKlientetEDietes

CREATE PROCEDURE GetDietClients
    @TargetDietaId INT
AS
BEGIN
    SELECT D.Dieta_id, D.Emer_dieta, D.Pershkrim_dieta, D.Numri_kalorive,
           K.Klient_id, K.IBAN, K.Numri_telefonit, K.Emer, K.Adresa, K.Email, K.Gjinia
    FROM Dieta D
    LEFT JOIN Porosi_Dieta PD ON D.Dieta_id = PD.Dieta_id
    LEFT JOIN Porosi P ON PD.Porosi_id = P.Porosi_id
    LEFT JOIN Abonim A ON P.Abonim_id = A.Abonim_id
    LEFT JOIN Klienti K ON A.Klienti_id = K.Klient_id
    WHERE D.Dieta_id = @TargetDietaId;
END;
EXEC GetDietClients @TargetDietaId = 1;



-- Krijimi i nje USER DEFINED DATA TYPE per numrin e telefonit ne tabelen klienti dhe vendosja e disa rregullave

CREATE TYPE dbo.NumriTelefonitType FROM VARCHAR(15);

CREATE RULE dbo.CheckNumriTelefonit
AS
    
    ISNUMERIC(@NumriTelefonit) = 1 AND
    @NumriTelefonit LIKE '06%';


CREATE RULE dbo.CheckNotNullNumriTelefonit
AS
    @NumriTelefonit IS NOT NULL;


CREATE RULE dbo.CheckNumriTelefonitLength
AS
    LEN(@NumriTelefonit) = 10;

	ALTER TABLE Klienti
    ADD NumriTelefonit dbo.NumriTelefonitType;

EXEC sp_bindrule 'dbo.CheckNumriTelefonit', 'Klienti.NumriTelefonit';
EXEC sp_bindrule 'dbo.CheckNotNullNumriTelefonit', 'Klienti.NumriTelefonit';
EXEC sp_bindrule 'dbo.CheckNumriTelefonitLength', 'Klienti.NumriTelefonit';

--TRIGGERS

-- Trigger p�r t� parandaluar futjen e nj� klienti me t� nj�jtin IBAN
CREATE TRIGGER trg_ParandalimiIBANduplikat
ON Klienti
INSTEAD OF INSERT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM inserted i JOIN Klienti k ON i.IBAN = k.IBAN)
    BEGIN
        THROW 51000, 'IBAN ekziston tashm�. Futja d�shtoi.', 1;
    END
    ELSE
    BEGIN
        INSERT INTO Klienti (Klient_id, IBAN, Numri_telefonit, Emer, Adresa, Email, Gjinia)
        SELECT Klient_id, IBAN, Numri_telefonit, Emer, Adresa, Email, Gjinia
        FROM inserted;
    END
END;


 --Perditesimi i kolones kosto ne tabelen porosi sa here qe nje diete e lidhur shtohet ose hiqet
CREATE TRIGGER tr_UpdateKosto 

ON Porosi_Dieta 

AFTER INSERT, DELETE 

AS 

BEGIN 

    UPDATE p 

    SET Kosto = ( 

        SELECT SUM(d.Numri_kalorive) 

        FROM Dieta d 

        JOIN Porosi_Dieta pd ON d.Dieta_id = pd.Dieta_id 

        WHERE pd.Porosi_id = p.Porosi_id 

    ) 

    FROM Porosi p 

    JOIN inserted i ON p.Porosi_id = i.Porosi_id OR p.Porosi_id = deleted.Porosi_id; 

END; 
--ky trigger ben te mundur qe kur nje rregjistrim abonimi te fshihet, te dhenat e porosise te lidhur jane fshire gjithashtu
CREATE TRIGGER tr_CascadeDeletePorosi 

ON Abonim 

AFTER DELETE 

AS 

BEGIN 

    DELETE FROM Porosi 

    WHERE Abonim_id IN (SELECT Abonim_id FROM deleted); 

END; 

--ky trigger kontrollon nese ka ndryshuar data e mbarimit te abonimit dhe nese abonimi ka mbaruar, shtohet nje shenim ne tabelen klienti
ALTER TABLE Klienti
ADD Shenime VARCHAR(255);

CREATE TRIGGER trgShtoShenimPasPefundimitAbonimi
ON Abonim
AFTER UPDATE
AS
BEGIN
    IF UPDATE(Data_mbarimit)
    BEGIN
        
        DECLARE @KlientiID INT, @DataMbarimit DATE;

        SELECT @KlientiID = i.Klienti_id, @DataMbarimit = i.Data_mbarimit
        FROM inserted i
        JOIN deleted d ON i.Abonim_id = d.Abonim_id;

      
        IF @DataMbarimit < GETDATE()
        BEGIN
           
            UPDATE Klienti
            SET Shenime = 'Klienti ka p�rfunduar abonimin'
            WHERE Klient_id = @KlientiID;
        END;
    END;
END;